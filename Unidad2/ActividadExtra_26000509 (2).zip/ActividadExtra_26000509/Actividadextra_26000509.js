let jugar = "si"
do{
  alert("Inica juego");
  let numpc = Math.floor(Math.random() * 9) + 1;
  let numU = parseInt(prompt("ingrese un numero entre 3 y 6"));
  while (isNaN(numU)|| numU < 1 || numU > 9){
    numU = parseInt(prompt("numero invalido, ingrese un numero entre 1 y 9"));
  }
  let eleccion = prompt("tu numero es mayor, menor o igual al de la computadora?").toLowerCase();
  let resultado = "";
  if (numU > numpc && eleccion === "mayor"){
    resultado = "¡Ha adivinado!";
  } else if (numU < numpc && eleccion === "menor"){
    resultado = "¡Ha adivinado!";
  }else if (numU === numpc && eleccion === "igual"){
    resultado = "¡Ha adivinado!";
  }else{
    resultado = "no adivino";
  }
  alert(
    "la computadora eligio " + numpc + ", usted eligio " + numU + ". su eleccion fue '" + eleccion + "'." + resultado
  );
  jugar = prompt("desea jugar otra vez(si / no)");
  if (jugar === null){
    jugar = "no";
  }else {
    jugar = jugar.trim().toUpperCase();
    if ( jugar === "sí") jugar = "si";
  }
}while (jugar === "si");
alert (
  "gracias por jugar\nNombre: FRANCISCO DE FRANCISCO PASCUAL\nCarnet: 26000509"
);
